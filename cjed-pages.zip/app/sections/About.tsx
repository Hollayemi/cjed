"use client";
import { motion } from "framer-motion";
import { siteConfig } from "@/app/config/site";
import SectionHeading from "@/app/components/SectionHeading";
import Reveal from "@/app/components/Reveal";
import Container from "@/app/components/Container";
import { stagger, fadeUp, slideRight } from "@/app/data/animation";

const valueIcons: Record<string, string> = {
  Justice: "⚖️",
  Integrity: "🛡️",
  Inclusion: "🤝",
  Excellence: "✦",
  Community: "🌱",
};

export default function About() {
  return (
    <section className="py-24 lg:py-32 bg-white">
      <Container>
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-20 items-center">
          {/* Left: Visual block */}
          <Reveal>
            <div className="relative">
              {/* Main image placeholder with layered design */}
              <div className="relative rounded-3xl overflow-hidden bg-[#0E3B2E] aspect-[4/5] max-w-lg">
                <img
                  src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&q=80"
                  alt="Legal aid and community support"
                  className="w-full h-full object-cover mix-blend-luminosity opacity-60"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0E3B2E] via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <p
                    className="text-white text-lg leading-snug"
                    style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                  >
                    "Bridging the gap between the law and the people it is meant to protect."
                  </p>
                </div>
              </div>

              {/* Floating reg card */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="absolute -bottom-6 -right-4 lg:-right-8 bg-[#D7A441] rounded-2xl px-6 py-4 shadow-xl"
              >
                <p className="text-[#0E3B2E] text-xs font-semibold tracking-wider uppercase mb-1">
                  Registration
                </p>
                <p className="text-[#0E3B2E] font-bold text-sm">{siteConfig.registration}</p>
              </motion.div>
            </div>
          </Reveal>

          {/* Right: Content */}
          <div className="flex flex-col gap-10">
            <SectionHeading
              eyebrow="Who We Are"
              title="Fighting for justice, one community at a time"
              subtitle={siteConfig.mission}
            />

            {/* Vision */}
            <Reveal delay={0.15}>
              <div className="p-6 rounded-2xl bg-[#F5F7F8] border border-gray-100">
                <h4 className="text-xs font-semibold tracking-widest uppercase text-[#D7A441] mb-3">
                  Our Vision
                </h4>
                <p className="text-gray-600 text-sm leading-relaxed">{siteConfig.vision}</p>
              </div>
            </Reveal>

            {/* Core Values */}
            <div>
              <Reveal>
                <h4 className="text-xs font-semibold tracking-widest uppercase text-[#0E3B2E]/50 mb-5">
                  Core Values
                </h4>
              </Reveal>
              <motion.div
                variants={stagger}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                className="grid grid-cols-1 sm:grid-cols-2 gap-3"
              >
                {siteConfig.coreValues.map((v) => (
                  <motion.div
                    key={v.name}
                    variants={fadeUp}
                    className="flex items-start gap-3 p-4 rounded-xl bg-[#F5F7F8] hover:bg-[#0E3B2E]/5 transition-colors duration-200 group"
                  >
                    <span className="text-lg flex-shrink-0 mt-0.5">
                      {valueIcons[v.name] || "•"}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-[#0E3B2E] group-hover:text-[#0E3B2E]">
                        {v.name}
                      </p>
                      <p className="text-xs text-gray-500 leading-relaxed mt-0.5">{v.description}</p>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
